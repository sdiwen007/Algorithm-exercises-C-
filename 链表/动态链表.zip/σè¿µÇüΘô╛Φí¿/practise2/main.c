//
//  main.c
//  practise2
//
//  Created by gxt-ios on 2019/12/31.
//  Copyright © 2019 gxt-ios. All rights reserved.
//

#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#define LEN sizeof(struct listNode)

int n;
struct listNode{
    int num;
    struct listNode *next;
};

struct listNode *creatHead(){
    struct listNode *head,*p1,*p2;
    p1 = p2 = (struct listNode *)malloc(LEN);
    n = 0;
    printf("please input linkNode\n");
    scanf("%d",&p1->num);
    head = NULL;
    while (p1->num>-10) {
        n = n+1;
        if(n==1) head = p1;
        else p2->next = p1;
        
        p2 = p1;
        p1 = (struct listNode *) malloc(LEN);
        scanf("%d",&p1->num);
    }
    p2->next = NULL;
    return head;
}


void print(struct listNode *head){
    struct listNode *p;
    p = head;
    while (p!=NULL) {
        printf("%d",p->num);
        p = p->next;
    }
}
//合并两个有序列表
struct listNode *node(struct listNode *head1, struct listNode *head2){
    struct listNode *p1,*p2,*p,*head = NULL;
    p1 = head1;
    p2 = head2;
    if (head1==NULL) {
        return head2;
    }
    if (head2==NULL) {
        return head1;
    }
    if (p1->num < p2->num) {
        head = p1;
        p1 = p1->next;
    }else{
        head = p2;
        p2 = p2->next;
    }
    p = head;
    while (p1!=NULL&&p2!=NULL) {
        if(p1->num <= p2->num){
            p->next=p1;
            p=p1;
            p1=p1->next;
        }else{
            p->next=p2;
            p=p2;
            p2=p2->next;
        }
    }
    
    if(p1!=NULL){
        p->next=p1;
    }else{
        p->next=p2;
    }
    
    return head;
}

//删除排序链表中的重复元素
struct listNode* deleteDuplicates(struct listNode* head){
    struct listNode *p,*p1;
    p = head;
    while (p->next!=NULL && p!=NULL) {
      if (p->next->num == p->num) {//如果当前结点和下一个结点值相等，那么可以删除下一个结点，跳到下下一个，不然继续。
            p1 = p->next;
            p->next = p->next->next;
        }else{
            p = p->next;
      }
    }
    return head;
}

//两个数倒序相加(链表非空，不用判断)，如果位数相加和超过10就进一位到下一位相加
struct listNode* addTwoNumbers(struct listNode* l1, struct listNode* l2){
    struct listNode *p1,*p2,*head;
    int n = 0;
    head = (struct listNode *)malloc(LEN);
    head->next = NULL;
    p1 = head;
    while (l1!=NULL||l2!=NULL||n) {
        p2 = (struct listNode *)malloc(LEN);
        p2->next = NULL;
        p1->next = p2;
        p1=p2;
        if (l1!=NULL) {
            n = n + l1->num;
            l1 = l1->next;
        }
        if (l2!=NULL) {
            n = n + l2->num;
            l2 = l2->next;
        }
//        l1=l1!=NULL?((void)(n+=l1->num),l1->next):l1;
//        l2=l2!=NULL?((void)(n+=l2->num),l2->next):l2;
        p1->num = n%10;
        n=n/10;
    }
    head = head->next;
    return head;
}

//删除链表中的倒数第N个节点
struct listNode *deleteOrderPoint(struct listNode *head, int n){
    struct listNode *p,*temp;
    p = head;
    int m = 0,a = 1;
    while (p->next!=NULL) {
        p = p->next;
        a++;
    }
    //判断删除的位数是否超出了链表的长度
    if (n>a) {
        printf("超出链表长度");
        return head;
    }
    p = head;
    //删除头结点
    if (m == a-n) {
        if(p->next!=NULL){
            head = p->next;
            return head;
        }else{
            return 0;
        }
    }
    while (p->next!=NULL) {
        if (m != (a-n)-1) {
            p = p->next;
        }else{
            temp = p->next;
            p->next = temp->next;
        }
        m++;
    }
    return head;
}

//相交链表
struct listNode *getIntersectionNode(struct listNode *headA, struct listNode *headB) {
    struct listNode *p = headA, *q = headB;
        int la, lb, lgap;
        for (la = 0; p; p = p->next, la++);  //链表A长度
        for (lb = 0; q; q = q->next, lb++);  //链表B长度
        lgap = la - lb;  //计算长度差
        if (la > lb){
            while (lgap--)  headA = headA->next;  //如果A更长，让A先走gap距离
        } else {
            while (lgap++)  headB = headB->next;  //反之让B先走gap距离
        }
        while (headA){  //逐一对比节点
            if (headA == headB) return headA;
            headA = headA->next;
            headB = headB->next;
        }
        return NULL;
}

//移除链表元素，做一组循环，删除指定值节点,注意是所有这样的值都要删除
struct listNode* removeElements(struct listNode* head, int val){
       struct listNode *p,*temp;
       p = head;
       if (head==NULL){ //如果是空节点
           return 0;
       }
       while (p!=NULL) {
           if(p->next==NULL){//最后一个元素
              if(p->num == val){
                 return 0;
              }else{
                  return head;
              }
           }else{
               //第一个元素如果是
               if(p->num == val&&head == p){
                   head = p->next;
                   p = p->next;
                }else{
                  //如果是中间元素，跳过
                  temp = p->next;
                  if (temp->num == val) {
                     p->next = p->next->next;
                   }else{
                     p = p->next;
                  }
               }
           }
       }
       return head;
}

//反转链表,可以采用迭代或者递归的方法
struct listNode* reverseList(struct listNode* head){
   struct listNode *res = NULL, *cur = head;
       while (cur){            //cur代表本次循环要处理的节点，此时head已提取至cur中
           head = head->next;  //head推进至下一个待处理节点
           cur->next = res;    //将新链表接在cur的后面，此时cur成为新链表的头
           res = cur;          //res也成为了新链表的头
           cur = head;         //cur提取旧链表中的head，进入下一轮处理
       }
       return res;
}


//判断链表是否是回文链表
bool isPalindrome(struct listNode* head){
    if (head == NULL&&head->next == NULL)
        return true;
    if (head->next->next ==NULL) {
        if (head->num == head->next->num)
            return true;
        else
            return false;
    }
    struct listNode *fastp,*slowp;
    fastp = head->next->next;
    slowp = head->next;
    // 快慢指针找到尾部及中部位置
    while (fastp && fastp->next!=NULL) {
        fastp = fastp->next->next;
        slowp = slowp->next;
    }
    
    //翻转中部前链表序列
    struct listNode *prep,*nextp;
    prep = nextp = NULL;
    while (head!=slowp) {
        nextp = head->next;
        head->next = prep;
        prep = head;
        head = nextp;
    }
    
    //若节点个数是奇数，则舍弃中间节点
    if (fastp != NULL && fastp->next == NULL) {
        slowp = slowp->next;
    }
    
    //回文匹配比较
    while (prep != NULL) {
        if (prep->num != slowp->num) {
            return false;
        }
        prep = prep->next;
        slowp = slowp->next;
    }
    return true;
}

//判断环形链表
bool hasCycle(struct listNode *head) {
    if (head == NULL || head->next == NULL) {
        return false;
    }
    struct listNode *fastp,*slowp;
    fastp = head->next->next;
    slowp = head->next;
    while(1){
    if (fastp==NULL || fastp->next==NULL)
        return false;
    else if (fastp==slowp || fastp->next==slowp)
        return true;
    else{
        fastp=fastp->next->next;
        slowp=slowp->next;
      }
    }
    return true;
}
//环形链表2
struct listNode *detectCycle(struct listNode *head) {
    if (head == NULL || head->next == NULL) {
        return NULL;
    }
    struct listNode *fastp,*slowp;
    slowp = head;
    fastp = head;
    //一直遍历，看看是否有相交的地方
    while (fastp && fastp->next && fastp->next->next) {
        slowp = slowp->next;
        fastp = fastp->next;
        fastp = fastp->next;
        if (slowp == fastp) {
            return slowp;
        }
    }
    //如果发现遍历最后是NULL,那么就说明这个不是循环
    if (!fastp || !fastp->next || !fastp->next->next) {
        return NULL;
    }
    slowp = head;
    while (slowp != fastp) {
        slowp = slowp->next;
        fastp = fastp->next;
    }
    return slowp;
}

//删除链表中的节点
void deleteNode(struct listNode* node) {
    node->num = node->next->num;
    node->next = node->next->next;
}


//返回链表的中间节点,采用快慢节点的方式
struct listNode* middleNode(struct listNode* head){
    struct listNode *fastp,*slowp;
    if (head->next == NULL) {
        return head;
    }
    fastp = head->next->next;
    slowp = head->next;
    
    while (fastp!=NULL&&fastp->next!=NULL) {
        fastp = fastp->next->next;
        slowp = slowp->next;
    }
    if (fastp==NULL) {
        return slowp;
    }
    if (fastp->next==NULL) {
        return slowp;
    }
    return slowp;
}


//二进制链表转整数
int getDecimalValue(struct listNode* head){
    int sum = 0, n = 0;
    struct listNode *p;
    p = head;
    while (p!=NULL) {
        if (p->num != 0) {
            sum += pow(2, n);
        }
        n++;
        p = p->next;
    }
    return sum;
}


//两两交换链表中的节点
struct listNode* swapPairs(struct listNode* head){
    if (head == NULL ||head->next==NULL) {
        return head;
    }
    struct listNode *tmp;
    tmp = head->next;
    head->next = swapPairs(tmp->next);
    tmp->next = head;
    return tmp;
}

//旋转链表，给定一个链表，旋转链表，将链表每个节点向右移动K个位置，其中K是非负数
struct listNode* rotateRight(struct listNode* head, int k){
    struct listNode *p,*q;
    int length = 0;
    p = head;
    while (p!=NULL) {
        q = p->next;
        length++;
        if (q==NULL) {
            break;
        }
        p = q;
    }
    if (length == 0 || length == 1) {
        return head;
    }
    int r = k%length;
    if (r==0) {
        return head;
    }
    p->next = head;    //形成链表
    int t = length-r;
    while (t--) {
        p = p->next;
    }
    //在打印时需要破坏掉环形链表，不然死循环
    q = p->next;
    p->next = NULL;
    return q;
}

//删除排序链表中的重复元素II
struct listNode* deleteDuplicatesII(struct listNode* head){
    struct listNode *p,*L,*q;
    if(!head||!(head->next))  return head;
    L=(struct listNode*)malloc(sizeof(struct listNode));
    L->next=NULL;//新建一个链表头结点指向原链表head,
    p=L;
    q=head->next;

    while(q)
    {
        if(q->num==head->num)//判断是否相等
        {
            while(q->num==head->num)
            {
                q=q->next;//若结点数据域相等，继续遍历
                if(!q)//判断是否到链表的末尾
                break;//跳出循环
            }
            if(q!=NULL)//不为表尾，将q的位置赋给head，q继续遍历
           {
            head=q;
            q=q->next;
           }
           else//为表尾，说明元素全都是重复的结点，令其为NULL，跳出循环
           {
            head=q=NULL;
           }
        }
        else//找到不为重复元素的结点
        {
            p->next=head;//指向这个结点
            p=p->next;//前移
            head=head->next;//前移
            if(!head)
             break;
            q=q->next;//前移
        }

    }
    if(head)//特殊情况时，当head有值，p为null时
        p->next=head;
    else
       p->next=NULL;
    
    return L->next;
}


//奇偶链表
struct listNode* oddEvenList(struct listNode* head){
    if (head == NULL || head->next == NULL || head->next->next == NULL) {
        return head;
    }
    struct listNode *p,*q,*t;
    p = head;
    q = head->next;
    t = head->next;
    
    while (true) {
        if (t==NULL || t->next == NULL) {
            p->next = q;
            return head;
        }
        p->next = t->next;
        p = t->next;
        t->next = p->next;
        t = p->next;
    }
    return NULL;
    
}


int main(int argc,char *argv[])
{
//    struct listNode *head1,*head2,*head;
//    head1 = creatHead();
//    head2 = creatHead();
//    head = node(head1, head2);
//    print(head);
    
//    struct listNode *head,*resultHead;
//    head = creatHead();
//    resultHead = deleteDuplicates(head);
//    printf("\n");
//    print(resultHead);
    
//      struct listNode *head1,*head2,*head;
//      head1 = creatHead();
//      head2 = creatHead();
//      head = addTwoNumbers(head1,head2);
//      print(head);
    
//    struct listNode *head1,*head2;
//    head1 = creatHead();
//    head2 = deleteOrderPoint(head1,1);
//    print(head2);
    
//    struct listNode *head1,*head2,*head;
//    head1 = creatHead();
//    head2 = creatHead();
//    head = getIntersectionNode(head1,head2);
//    print(head);
    
//    struct listNode *head1,*head2;
//    int n = 6;
//    head1 = creatHead();
//    head2 = removeElements(head1,n);
//    print(head2);
    
//    struct listNode *head1,*head2;
//    head1 = creatHead();
//    head2 = reverseList(head1);
//    print(head2);
    
    
//    struct listNode *head1;
//    bool back;
//    head1 = creatHead();
//    back = isPalindrome(head1);
//    if (back == true) {
//        printf("此链表是回文链表\n");
//    }else{
//        printf("此链表不是回文链表\n");
//    }
    
    
//    struct listNode *head1;
//    bool back;
//    head1 = creatHead();
//    back = hasCycle(head1);
//    if (back == true) {
//        printf("这是一个环形链表");
//    }
//    else{
//        printf("这是一个环形链表");
//    }
    
//    struct listNode *head,*node;
//    head = creatHead();
//    print(head);
//    deleteNode(node);
    
    
//    struct listNode *head,*head1;
//    head = creatHead();
//    head1= middleNode(head);
//    printf("%d",head1->num);
   
    
//    struct listNode *head,*head1;
//    head = creatHead();
//    head1 = reverseList(head);
//    int result = getDecimalValue(head1);
//    printf("sum = %d",result);
    
    
//    struct listNode *head,*head1;
//    head = creatHead();
//    head1 = detectCycle(head);
//    printf("sum = %d",head1->num);
    
//    struct listNode *head,*head2;
//    head = creatHead();
//    head2 = swapPairs(head);
//    print(head2);
    
//    struct listNode *head,*head1;
//    head = creatHead();
//    head1 = rotateRight(head,2);
//    print(head1);
    
//    struct listNode *head,*head1;
//    head = creatHead();
//    head1 = deleteDuplicatesII(head);
//    print(head1);
    
    struct listNode *head,*head1;
    head = creatHead();
    head1 = oddEvenList(head);
    print(head1);
    return 0;
}

