//
//  main.c
//  动态链表
//
//  Created by gxt-ios on 2019/12/26.
//  Copyright © 2019 gxt-ios. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>

#define LEN sizeof(struct Student)
struct Student
{
    long num;//学号
    float score;//分数
    struct Student *next;//下一个节点
};
int n;

//创建一个链表
struct Student * headCreat(void){
    struct Student *head, *p1, *p2;
    n = 0;
    p1 = p2 = (struct Student *)malloc(LEN);//开辟一个新单元
    printf("请输入节点的值,最后输入（0，0)表示结束！\n");
    scanf("%ld,%f",&p1->num,&p1->score);
    head = NULL;
    while (p1->num != 0) {
        n = n + 1;
        if (n == 1) {
            head = p1;
        }else{
            p2->next = p1;
        }
        p2 = p1;
        p1 = (struct Student *)malloc(LEN);
        scanf("%ld,%f",&p1->num,&p1->score);
    }
    p2->next = NULL;
    return head;
}

//打印链表
void print(struct Student *head){
    struct Student *p;
    printf("\nNow,These %d records are:\n",n);
    p = head;
    if (head != NULL) {//首先判断是否是空链表，如果不是就开始循环打印
        do {
            printf("%ld %5.1f\n",p->num,p->score);
            p = p->next;
        } while (p!=NULL); //尾结点结束
    }
}


int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    struct Student *qt;
    qt = headCreat();
    printf("\nnum:%ld\nscore:%f\n",qt->num,qt->score);
    print(qt);
    return 0;
}
