//
//  main.c
//  pratcise1
//
//  Created by gxt-ios on 2019/12/27.
//  Copyright © 2019 gxt-ios. All rights reserved.
//

#include <stdio.h>
#define N 13
#define LEN sizeof(struct Student)

#define LA 4
#define LB 5

struct student{
    int num;
    char name[8];
    struct student *next;
}a[LA],b[LB];


struct{
    int year;
    int month;
    int day;
}date;

struct Student{
    long num;
    float score;
    struct Student *next;
};
int n,sum = 0;

struct person{
    int number;
    int nextp;
} Link[N+1];

//建立链表的函数
struct Student *crea(){
    struct Student *head;
    struct Student *p1,*p2;
    n = 0;
    p1 = p2 = (struct Student *) malloc(LEN);
    printf("please input link numbers:\n");
    scanf("%ld,%f",&p1->num,&p1->score);
    head = NULL;
    while (p1->num) {
        n = n + 1;
        if (n==1) {
            head = p1;
        }else{
            p2->next = p1;
        }
        p2 = p1;
        p1 = (struct Student *) malloc(LEN);
        scanf("%ld,%f",&p1->num,&p1->score);
    }
    p2->next = NULL;
    return head;
}
struct Student *crea2(){
    struct Student *head;
    struct Student *p1,*p2;
    n = 0;
    p1 = p2 = (struct Student *) malloc(LEN);
    printf("please input link numbers:\n");
    scanf("%ld,%f",&p1->num,&p1->score);
    head = NULL;
    while (p1->num) {
        n = n + 1;
        if (n==1) {
            head = p1;
        }else{
            p2->next = p1;
        }
        p2 = p1;
        p1 = (struct Student *) malloc(LEN);
        scanf("%ld,%f",&p1->num,&p1->score);
    }
    p2->next = NULL;
    return head;
}

//打印链表的内容
void print(struct Student *head){
    struct Student * p;
    printf("\nNow,These %d records are:\n",n);
    p = head;
    if (head!=NULL) {
        do {
            printf("%ld %5.1f\n",p->num,p->score);
            p = p->next;
        } while (p!=NULL);
    }
}
//写一个函数del，用来删除动态链表中制定的结点
struct Student *deletePoint(struct Student *head , int n){
    struct Student *p1,*p2;
    if (head == NULL) {
        printf("\n list null!\n");
        return head;
    }
    p2 = p1 = head;
    //删除head结点
    if (n == p1->num && p1->next != NULL) {
        head = p1->next;
    }else{
        while (n != p1->num && p1->next != NULL) {
            p2 = p1;
            p1 = p1->next;
            if (n == p1->num) {
                if (p1 == head) {
                    head = p1->next;
                }else{
                    p2->next = p1->next;
                    printf("delete:%d\n",n);
                }
            }
        }
    }
    return head;
}
//写一个函数insert，用来向一个动态链表中插入结点
struct Student *insertPoint(struct Student *head , struct Student *p){
    struct Student *p0,*p1,*p2;
    p0  = p;
    p1 = p2 = head;
    //首先判断要插入的表非空，插入结点即为head结点
    if (head == NULL) {
        head = p0;
        p0->next = NULL;
    }
    else{
        //如果只有一个head结点的情况,分在前和在后两种情况
        if (p1->next == NULL) {
            if (p0->num<=p1->num) {
                head = p0;
                p0->next = p1;
                p1->next = NULL;
            }else{
                p1->next = p0;
                p0->next = NULL;
            }
        }else{
            //不止一个结点的情况
            while ((p0->num>p1->num) && (p1->next!=NULL)) {
                p2 = p1;
                p1 = p1->next;
            }

            if (p0->num <= p1->num) {
                if (head == p1) {
                    head = p0;
                }else{
                    p2->next = p0;
                }
                p0->next = p1;
            }else{
                p1->next = p0;
                p0->next = NULL;
            }
        }
    }
    n = n + 1;
    return head;
}
// 定义一个结构体变量，计算该日在本年中是第几天，注意闰年问题
int getDays(int year, int month, int day){
   int i,days;
   int month_Days[12] = {31,28,13,30,31,30,31,31,30,31,30,31};
   days = 0;
   for (i=0; i<month; i++) {
       days += month_Days[i];
   }
   days = days + date.day;
   //如果是闰年且超过第二个月，那么二月就是增加29天，如果是平年，那么增加28天
   if (((date.year%4==0&&date.year%100!=0)||date.year%400==0)&&(date.month>=3)) {
       days = days + 1;
   }
   printf("The day is %d day\n",days);
    return days;
}
/**
 *已有a,b两个链表，每一个链表中的结点包括学号，成绩。要求把两个链表合并，按学号升序排列。1.先创建两个链表，再将链表合并起来。
 */
struct Student *bindLink(struct Student *head1, struct Student *head2){
     struct Student *pa1,*pa2,*pb1,*pb2;
     pa2 = pa1 = head1;
     pb2 = pb1 = head2;

    //首先判断这两个链表是否为空
    if (head1 == NULL && head2 == NULL) {
        printf("两个链表均为空");
        return 0;
    }
    if (head1 == NULL) {
        while (pb1 != NULL) {
            pb1 = pb1->next;
        }
        return head2;
    }
    if (head2 == NULL) {
        while (pa1 != NULL) {
            pa1 = pa1->next;
        }
        return head1;
    }
    
    //正常情况下的操作
    do {
        //head结点值较小
        while ((pb1->num>pa1->num)&&(pa1->next!=NULL)) {
            pa2 = pa1;
            pa1 = pa1->next;
        }
        
        //只要B链表的结点比A链表的结点大就行，不管两条链表有一个结点
        if (pb1->num<=pa1->num) {
            if (head1 == pa1) {
                head1 = pb1;
            }else{
                pa2->next = pb1;
            }
            pb1 = pb1->next;//这一段需要理解
            pb2->next = pa1;
            pa2 = pb2;
            pb2 = pb1;
        }
    } while ((pa1->next!=NULL)||(pa1==NULL && pb1->next!=NULL));
    
    if ((pb1!=NULL)&&(pb1->num>pa1->num)&&(pa1->next == NULL)) {
        pa1->next = pb1;
    }
    return head1;
}
/**
 * 针对学号进行单链表排序,冒泡排序，结点值交换法
 */
void sort(struct Student *head){
    struct Student *p,*q;
    for (p = head; p!=NULL; p = p->next) {
        for (q = p->next; q!=NULL; q= q->next) {
            if (p->num > q->num) {
                long t1 = p->num; p->num = q->num; q->num = t1;
                float t2 = p->score; p->score = q->score; q->score = t2;
            }
        }
    }
}
/*
 * 删除两个链表中的相同结点
 */
void delete()
{
    struct student a[LA] = {{101,"Wang"},{102,"Li"},{105,"Zhang"},{106,"Wei"}};
    struct student b[LB] = {{103,"Zhang"},{102,"Huang"},{107,"Xue"},{106,"Liu"}};
    int i;
    struct student *p = NULL,*p1,*p2,*head1,*head2;
    head1 = a;
    head2 = b;
    printf("list A: \n");
    //将上面的数据串联成链表
    for (p1=head1,i=1; i<=LA; i++) {
        if (i<LA) {
            p1->next = a + i;
        }else{
            p1->next = NULL;
        }
        printf("%4d%8s\n",p1->num,p1->name);
        if (i<LA) {
            p1 = p1->next;
        }
    }

    printf("list B: \n");
    for (p2=head2,i=1; i<=LB; i++) {
        if (i<LB) {
            p2->next = b + i;
        }else{
            p2->next = NULL;
        }
        printf("%4d%8s\n",p2->num,p2->name);
        if (i<LB) {
            p2 = p2->next;
        }
    }
    //大循环从链表a中剔除b中存在的结点
    p1 = head1;
    while (p1!=NULL) {
        p2 = head2;
        while (p1->num!=p2->num&&p2->next!=NULL) {
            p2 = p2->next;
        }
        if (p1->num == p2->num) {
           if(p1 == head1)
             head1 = p1->next;
           else
           {   p->next = p1->next;
               p1=p1->next;
           }
        }else{
            //如果不是，将上一个值赋给p。为了b免得下一个结点删除，无法进行。
            p = p1;
            p1 = p1->next;
        }
    }
    printf("\nresult:\n");
    p1 = head1;
    while (p1!=NULL) {
        printf("%4d %8s\n",p1->num,p1->name);
        p1 = p1->next;
    }
}
/*
 * 约瑟夫环问题。13个人围成一个圈，从第一个人开始顺序报号1，2，3...，凡事报到3的人退出圈子，找出最后留在圈子中的人原来的序号，用链表实现。
  //约瑟夫环，这是一个经典的数学问题，目前常见的编程题是猴子选王
 */
void yesefu(){
    int i,count,h;
    for (i = 1; i<= N; i++) {
        if (i==N) {
            Link[i].nextp = 1;
        }else{
            Link[i].nextp = i+1;
        }
        Link[i].number = i;
    }
    count = 0;
    h = N;
    printf("squeence that persons leave the circle:\n");
    while (count<N-1) {
        i = 0;
        while (i!=3) {
            h = Link[h].nextp;
            if (Link[h].number) {
                i++;
            }
        }
        printf("%4d",Link[h].number);
        Link[h].number = 0;
        count++;
    }
    printf("\nThe last one is\n");
    for (i = 1; i <= N; i++) {
        if (Link[i].number) {
            printf("%3d\n",Link[i].number);
        }
//        printf("\n");
    }
}



int main(int argc, const char * argv[]) {
//   printf("please input the day:\n");
//   scanf("%d,%d,%d",&date.year,&date.month,&date.day);
//   getDays(date.year, date.month, date.day);
    
    
//    struct Student *head,*head2,*headRsult;
//    printf("input list a:\n");
//    head = crea();
//    sort(head);
//    sum = sum + n;
//    printf("input list b:\n");
//    head2 = crea();
//    sort(head2);
//    sum = sum + n;
//    headRsult = bindLink(head, head2);
//    print(headRsult);
    
    
//    /*删除一个结点*/
//    head = deletePoint(head, 1001);
//    print(head);
    
    
    /*增加一个结点*/
//    struct Student insertP;
//    printf("please input insert point content\n");
//    scanf("%ld,%f",&insertP.num,&insertP.score);
//    head = insertPoint(head,&insertP);
//    print(head);
    
    //删除两个链表中的相同结点
//    delete();
    
    yesefu();
    
    return 0;
}

